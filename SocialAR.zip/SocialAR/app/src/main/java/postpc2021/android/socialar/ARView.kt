package postpc2021.android.socialar

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ARView : AppCompatActivity() {
	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_a_r_view)
	}
}